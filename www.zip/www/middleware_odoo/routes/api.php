<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('Login', 'UserController@login');
Route::post('Register', 'UserController@register');
Route::middleware('auth:api')->group(function () {
    Route::get('Invoice', 'InvoiceController@index');
    Route::get('InvoiceBtos/{id}', 'InvoiceController@invoice_btos');
    Route::post('InvoiceBtos', 'InvoiceController@tarik_invoice_btos');
    Route::post('InvoiceStore', 'InvoiceController@store');
    Route::post('InvoiceShow', 'InvoiceController@showdata');
    // Route::resource('products', 'PassportController@products');

    Route::post('OdooStore', 'OdooController@store');
    Route::post('OdooUpdateSol', 'OdooController@updatesol');
    Route::post('OdooCreateInvoice', 'OdooController@createInvoice');

    Route::post('OdooStoreBtos', 'OdooControllerBtos@store');
    Route::post('OdooUpdateSolBtos', 'OdooControllerBtos@updatesol');
    Route::post('OdooCreateInvoiceBtos', 'OdooControllerBtos@createInvoice');
});

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
