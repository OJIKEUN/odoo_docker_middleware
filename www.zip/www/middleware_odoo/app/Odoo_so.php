<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Odoo_so extends Model
{
    public $table = "ODOO_SO";

    protected $fillable = [
        'DB_',
        'UID_',
        'PASSWORD_',
        'CATEGORY_',
        'FUNCTION_',
        'NAME_',
        'PARTNER_ID_',
        'COMPANY_ID_',
        'XML',
        'SO_ID',
    ];
}