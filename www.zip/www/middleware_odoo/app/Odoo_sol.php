<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Odoo_sol extends Model
{
    public $table = "ODOO_SOL";

    protected $fillable = [
        'DB_',
        'UID_',
        'PASSWORD_',
        'CATEGORY_',
        'FUNCTION_',
        'ORDER_ID_',
        'PRODUCT_TEMPLATE_ID_',
        'PRODUCT_ID_',
        'DESCRIPTION_',
        'PRICE_UNIT_',
        'X_KOLI_',
        'PRODUCT_UOM_QTY_',
        'CUSTOMER_LEAD',
        'PRODUCT_UOM',
        'TAX_ID',
        'XML',
        'SOL_ID',
    ];
}