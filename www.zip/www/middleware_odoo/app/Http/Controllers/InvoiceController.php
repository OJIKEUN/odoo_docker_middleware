<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Invoice;
use App\Invoice_btos;
use DB;

class InvoiceController extends Controller
{
    public function __construct()
    {
        $this->url_erp = 'https://qa-erpbatam.ptsisi.id/api';
    }

    public function index(){
        // $invoice = auth()->user()->odoo_sos;
        dd($odoo);
        // $invoice = [
        //     'MANIFEST'=>'a',
        //     'WAKTU_MANIFEST'=>'a',
        //     'ACCEPTANCE'=>'b',
        //     'PAYMENT'=>'c',
        //     'HANDOVER'=>'d',
        // ];
        // return response()->json([
        //     'success'=>true,
        //     'data'=>$invoice,
        // ]);
    }

    public function showdata(Request $request){
        $data_json = $request->input();
        echo $data_json;
        // $invoice = auth()->user()->invoice()->find($id);

        // if(!$invoice){
        //     return response()->json([
        //         'success'=>false,
        //         'data'=>'Data not found',
        //     ], 400);
        // }

        // return response()->json([
        //     'success'=>true,
        //     'data'=>$data->toArray(),
        // ], 400);
    }
    
    public function store(Request $request){
        $data_json = $request->input();
        $data = auth()->user()->odoo_sos()->find($data_json['NOMOR_SMU']);
        // echo 'data1;aaa,data2:bbb';
        $data = [
            'MANIFEST'=>'a',
            'WAKTU_MANIFEST'=>'a',
            'ACCEPTANCE'=>'b',
            'PAYMENT'=>'c',
            'HANDOVER'=>'d',
        ];
        return response()->json([
            'success'=> true,
            'data'=> $data,
        ]);
        // $token_forca = json_decode($this->get_token())->resultdata->token;
        // $data_json = json_encode($request->input());
        // $setInvoice = $this->setInvoice($token_forca, $data_json);
        
        // $header = [
        //     'Forca-Token' => $token_forca,
        // ];

        // $invoice = new Invoice();
        // $invoice->HEADER = json_encode($header);
        // $invoice->REQUEST = json_encode($request->input());
        // $invoice->RESPONSE = $setInvoice;
        // if(auth()->user()->invoices()->save($invoice)){
        //     return response()->json([
        //         'success'=> true,
        //         'data'=> $invoice,
        //     ]);
        // }
    }

    public function tarik_invoice_btos(Request $request){
        $json_data = json_decode($this->invoice_btos());
        $token_forca = json_decode($this->get_token())->resultdata->token;
        $data_json = json_encode($request->input());
        $setInvoice = $this->setInvoice($token_forca, $data_json);
        $header = [
            'Forca-Token' => $token_forca,
        ];
        $invoice = new Invoice();
        $invoice->HEADER = json_encode($header);
        $invoice->REQUEST = json_encode($request->input());
        $invoice->RESPONSE = $setInvoice;
        // $invoice = new Invoice_btos();
        // foreach($json_data->data as $row){
            // $invoice->NAME = 'BARGE';
            // $invoice->PAYMENT_DATE = date('d-m-y H:i:s');
            // $invoice->NOMOR_PKK = 'PKK';
            // $invoice->NAME = $row->name;
            // $invoice->PAYMENT_DATE = $row->payment_date;
            // $invoice->NOMOR_PKK = $row->nomor_pkk;
            // var_dump($row->name);
            if(auth()->user()->invoices()->save($invoice)){
                return response()->json([
                    'success'=> true,
                    'data'=> $invoice,
                ]);
            }
        // }
    }

    function get_token(){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/ws/authentication/v1/login',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => 'username=API&password=api123',
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/x-www-form-urlencoded'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function setInvoice($token_forca, $data){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/ws/transaction/v1/setInvoice',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            'Forca-Token: '.$token_forca,
            'Content-Type: application/json'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    public function invoice_btos(){
        $date = date('Y-m');
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://bctos-be.aksiteknologi.com/api/custom_report/run/82/VIEW',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => array(
                'Accept: application/json',
				'Authorization: c2d951f3-3b08-4b3d-af8b-afbc447cf859_336448cc-8c28-40f1-ac16-be2c9e84bc4f',
				'Referer: logistika.co.id:80'
            ),
			CURLOPT_POSTFIELDS => '_P1='.$date,
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        // $array = json_decode($response, true);
		// echo json_encode($array);
        return $response;
    }
}
