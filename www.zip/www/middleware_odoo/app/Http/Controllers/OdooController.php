<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Odoo_so;
use App\Odoo_sol;
use DB;

class OdooController extends Controller
{
    public function __construct()
    {
        // Production
        // $this->url_erp = 'http://159.223.61.53:8069/xmlrpc';
        // $this->db = 'perserobatam';
        // $this->uid = '2';
        // $this->password = 'iCARS2019';

        // Development
        $this->url_erp = 'http://159.223.47.215:8069/xmlrpc';
        $this->db = 'perserobatam';
        $this->uid = '0';
        $this->password = '2024@Batam';

        // Testing Local
        // $this->url_erp = 'http://host.docker.internal:8069/xmlrpc';
        // $this->db = 'testing1';
        // $this->uid = '0';
        // $this->password = 'testing1';

    }


    public function index(){

    }

    public function store(Request $request){
        \Log::info('🚨 MASUK KE FUNGSI store() OdooControllerBtos');
        $data_json = $request->input();

        // var_dump($data_json);

        $db = $this->db;
        $uid = $this->uid;
        $password = $this->password;
        $category = $data_json['category'];
        $function = $data_json['function'];
        $state = $data_json['state'];
        $name = $data_json['name'];
        $partner_id = $data_json['partner_id'];
        $payment_term_id = $data_json['payment_term_id'];
        $company_id = $data_json['company_id'];
        $pricelist_id = $data_json['pricelist_id'];
        $detail = $data_json['detail'];

        $xml = "<methodCall>
                    <methodName>execute_kw</methodName>
                    <params>
                        <!-- Authentication Parameters -->
                        <param><value><string>".$db."</string></value></param>
                        <param><value><int>".$uid."</int></value></param>
                        <param><value><string>".$password."</string></value></param>

                        <!-- Insert a Sale Order -->
                        <param><value><string>".$category."</string></value></param>
                        <param><value><string>".$function."</string></value></param>
                        <param>
                        <value>
                            <array>
                            <data>
                                <value>
                                <struct>
                                    <!-- Sale Order Fields -->
                                    <member>
                                    <name>name</name>
                                    <value>".$name."</value> <!-- Nomor WO -->
                                    </member>
                                    <member>
                                    <name>partner_id</name>
                                    <value><int>".$partner_id."</int></value> <!-- Partner ID / Customer ID -->
                                    </member>
                                    <member>
                                    <name>state</name>
                                    <value><string>".$state."</string></value>
                                    </member>
                                    <member>
                                    <name>payment_term_id</name>
                                    <value><int>".$payment_term_id."</int></value>
                                    </member>
                                    <member>
                                    <name>company_id</name>
                                    <value><int>".$company_id."</int></value> <!-- Default -->
                                    </member>
                                    <member>
                                    <name>pricelist_id</name>
                                    <value><int>".$pricelist_id."</int></value>
                                    </member>
                                </struct>
                                </value>
                            </data>
                            </array>
                        </value>
                        </param>
                    </params>
                </methodCall>";
        // echo $xml;
            $xmlsearchso = "<methodCall>
                    <methodName>execute_kw</methodName>
                    <params>
                        <param><value><string>".$db."</string></value></param>
                        <param><value><string>".$uid."</string></value></param>
                        <param><value><string>".$password."</string></value></param>

                        <param><value><string>".$category."</string></value></param>
                        <param><value><string>search</string></value></param>

                        <param>
                        <value>
                            <array>
                            <data>
                                <value>
                                <array>
                                    <data>
                                    <value>
                                        <array>
                                        <data>
                                            <value><string>name</string></value>
                                            <value><string>=</string></value>
                                            <value><string>".$name."</string></value>
                                        </data>
                                        </array>
                                    </value>
                                    </data>
                                </array>
                                </value>
                            </data>
                            </array>
                        </value>
                        </param>
                    </params>
                </methodCall>";
        
        $data_response_so = $this->check_existing_so($xml);

        // CETAK RAW RESPONSE DARI ODOO SEBELUM DI-PARSE
        \Log::info('🔍 Raw XML dari check_existing_so', ['response' => $data_response_so]);

        $xml_object_so = simplexml_load_string($data_response_so);

        // VALIDASI PARSING
        if (!is_object($xml_object_so) || !isset($xml_object_so->params)) {
            \Log::error('❌ Gagal parse XML: tidak ada node params', [
                'xml_string' => $data_response_so,
                'parsed_object' => $xml_object_so
            ]);
            return response()->json(['error' => 'Invalid XML: no params node'], 500);
        }

        $value_so = (int)$xml_object_so->params->param->value->array->data->value->int;         
            
            $data_response = $this->insert_so($xml);
            \Log::info('Insert SO Response:', [$data_response]);
            if (!$xml_object) {
                \Log::error('Gagal parse XML dari insert_so response');
                return response()->json(['error' => 'Invalid XML response from Odoo'], 500);
            }
            $xml_object = simplexml_load_string($data_response);
            $json_array = json_decode(json_encode($xml_object), true);
            $value = $json_array['params']['param']['value']['int'];

            $odoo_so_oracle                 = new Odoo_so();
            $odoo_so_oracle->DB_            = $db;
            $odoo_so_oracle->UID_           = $uid;
            $odoo_so_oracle->PASSWORD_      = $password;
            $odoo_so_oracle->CATEGORY_      = $category;
            $odoo_so_oracle->FUNCTION_      = $function;
            $odoo_so_oracle->ORDER_NAME_    = $name;
            $odoo_so_oracle->PARTNER_ID_    = $partner_id;
            $odoo_so_oracle->COMPANY_ID_    = $company_id;
            $odoo_so_oracle->XML            = $xml;
            $odoo_so_oracle->SO_ID          = $value;
            if(auth()->user()->odoo_sos()->save($odoo_so_oracle)){
                $message_oracle = 'Insert success';
            }else{
                $message_oracle = 'Insert failed';
            }

            if($company_id == '18'){
                $xml_to_so = "<methodCall>
                    <methodName>execute_kw</methodName>
                    <params>
                        <!-- Authentication Parameters -->
                        <param><value><string>".$db."</string></value></param>
                        <param><value><int>".$uid."</int></value></param>
                        <param><value><string>".$password."</string></value></param>
    
                        <!-- Update Sale Order -->
                        <param><value><string>sale.order</string></value></param> <!-- Model yang di-update -->
                        <param><value><string>write</string></value></param> <!-- Metode untuk update data -->
                        <param>
                        <value>
                            <array>
                            <data>
                                <!-- ID dari sale order yang ingin di-update -->
                                <value>
                                <array>
                                    <data>
                                    <value><int>".$value."</int></value> <!-- ID sale order, ganti dengan ID SO yang sebenarnya -->
                                    </data>
                                </array>
                                </value>
    
                                <!-- Data yang akan di-update -->
                                <value>
                                <struct>
                                    <!-- Update field partner_id -->
                                    <member>
                                    <name>state</name>
                                    <value><string>sale</string></value> <!-- Replace with actual partner_id -->
                                    </member>
    
                                    <!-- Update atau tambahkan order lines -->
                        
                                </struct>
                                </value>
                            </data>
                            </array>
                        </value>
                        </param>
                    </params>
                    </methodCall>";
                $update_so = $this->update_so_sol($xml_to_so);
                $message_update = "Update so success";
            }else{
                $message_update = "Update so failed";
            }

            $message_odoo = 'Insert success';
            foreach($detail as $rw){
                $xml_detail = "<methodCall>
                <methodName>execute_kw</methodName>
                    <params>
                        <param><value><string>".$db."</string></value></param>
                        <param><value><int>".$uid."</int></value></param> <!-- UID -->
                        <param><value><string>".$password."</string></value></param>
                        <param><value><string>".$rw['category']."</string></value></param>
                        <param><value><string>".$function."</string></value></param>
                        <param>
                        <value>
                            <array>
                            <data>
                            
                                <value>
                                <struct>
                                    <member>
                                    <name>order_id</name>
                                    <value><int>".$value."</int></value>
                                    </member>
                                    <member>
                                    <name>product_template_id</name>
                                    <value><int>".$rw['product_template_id']."</int></value>
                                    </member>
                                    <member>
                                    <name>product_id</name>
                                    <value><int>".$rw['product_id']."</int></value> <!-- ID Produk -->
                                    </member>
                                    <member>
                                    <name>name</name>
                                    <value><string>".$rw['name']."</string></value> <!-- Nama produk atau deskripsi -->
                                    </member>
                                    <member>
                                    <name>price_unit</name>
                                    <value><double>".$rw['price_unit']."</double></value> <!-- Harga per unit -->
                                    </member>
                                    <member>
                                    <name>x_koli</name>
                                    <value><double>".$rw['x_koli']."</double></value> <!-- Kuantitas -->
                                    </member>
                                    <member>
                                    <name>product_uom_qty</name>
                                    <value><double>".$rw['product_uom_qty']."</double></value> <!-- Kuantitas -->
                                    </member>
                                    <member>
                                    <name>customer_lead</name>
                                    <value><double>".$rw['customer_lead']."</double></value> <!-- Lead time -->
                                    </member>
                                    <member>
                                    <name>product_uom</name>
                                    <value><int>".$rw['product_uom']."</int></value> <!-- ID UOM (Unit of Measure) -->
                                    </member>
                                    <!-- <member>
                                    <name>tax_id</name>
                                    <value>
                                        <array>
                                        <data>
                                            <value><int>1</int></value>  --> <!-- ID Pajak -->
                                        <!--</data>
                                        </array>
                                    </value>
                                    </member>
                                    -->
                                </struct>
                                </value>
                            </data>
                            </array>
                        </value>
                        </param>
                    </params>
                </methodCall>";
                $data_response_detail = $this->insert_so($xml_detail);
                $xml_details = simplexml_load_string($data_response_detail);
                $value_detail = (int)$xml_details->params->param->value->int;

                $odoo_sol_oracle                        = new Odoo_sol();
                $odoo_sol_oracle->DB_                   = $db;
                $odoo_sol_oracle->UID_                  = $uid;
                $odoo_sol_oracle->PASSWORD_             = $password;
                $odoo_sol_oracle->CATEGORY_             = $category;
                $odoo_sol_oracle->FUNCTION_             = $function;
                $odoo_sol_oracle->ORDER_ID_            = $value;
                $odoo_sol_oracle->PRODUCT_TEMPLATE_ID_ = $rw['product_template_id'];
                $odoo_sol_oracle->PRODUCT_ID_          = $rw['product_id'];
                $odoo_sol_oracle->DESCRIPTION_         = $rw['name'];
                $odoo_sol_oracle->PRICE_UNIT_          = $rw['price_unit'];
                $odoo_sol_oracle->X_KOLI_              = $rw['x_koli'];
                $odoo_sol_oracle->PRODUCT_UOM_QTY_     = $rw['product_uom_qty'];
                $odoo_sol_oracle->CUSTOMER_LEAD        = $rw['customer_lead'];
                $odoo_sol_oracle->PRODUCT_UOM          = $rw['product_uom'];
                $odoo_sol_oracle->TAX_ID               = '';
                $odoo_sol_oracle->XML                  = $xml_detail;
                $odoo_sol_oracle->SOL_ID               = $value_detail;

                if(auth()->user()->odoo_sols()->save($odoo_sol_oracle)){
                    
                }
                // var_dump($rw['product_template_id']);
                $result_detail[] = array_merge($result, array(
                    'id' => $value_detail, 
                    'name' => $rw['name'], 
                    'price_unit' => $rw['price_unit'], 
                    'x_koli' => $rw['x_koli'], 
                    'product_uom_qty' => $rw['product_uom_qty']
                ));
            }
        }else{
            $message_odoo = 'Row is ready';
            $message_oracle = 'Row is ready';
            $value = $value_so;
            $result_detail[] = array_merge($result, array(
                'id' => '', 
                'name' => '', 
                'price_unit' => '', 
                'x_koli' => '', 
                'product_uom_qty' => ''
            ));
        }
        
        return response()->json([
            'success' => true,
            'message_odoo' => $message_odoo,
            'message_oracle' => $message_oracle,
            'message_update' => $message_update,
            'data' => [array('name' => $name, 'id' => $value, 'details' => [$result_detail])],
        ]);
    }

    public function createInvoice(Request $request)
    {
        $data_json = $request->input();

        $db = $this->db;
        $uid = $this->uid;
        $password = $this->password;
        $category = $data_json['category'];
        $function = $data_json['function'];
        $name = $data_json['name'];
        $journal_id = $data_json['journal_id'];
        $amount = $data_json['amount'];
        $company_id = $data_json['company_id'];

        $xmlsearchso = "<methodCall>
                    <methodName>execute_kw</methodName>
                    <params>
                        <param><value><string>".$db."</string></value></param>
                        <param><value><string>".$uid."</string></value></param>
                        <param><value><string>".$password."</string></value></param>

                        <param><value><string>".$category."</string></value></param>
                        <param><value><string>search</string></value></param>

                        <param>
                        <value>
                            <array>
                            <data>
                                <value>
                                <array>
                                    <data>
                                    <value>
                                        <array>
                                        <data>
                                            <value><string>name</string></value>
                                            <value><string>=</string></value>
                                            <value><string>".$name."</string></value>
                                        </data>
                                        </array>
                                    </value>
                                    </data>
                                </array>
                                </value>
                            </data>
                            </array>
                        </value>
                        </param>
                    </params>
                </methodCall>";
        
        $data_response_so = $this->search_so($xmlsearchso);
        $xml_object_so = simplexml_load_string($data_response_so);
        $value_so = (int)$xml_object_so->params->param->value->array->data->value->int;
        
        $xml_create_invoice = "<methodCall>
            <methodName>execute_kw</methodName>
            <params>
                <param><value><string>".$db."</string></value></param>
                <param><value><string>".$uid."</string></value></param>
                <param><value><string>".$password."</string></value></param>

                <param><value><string>".$category."</string></value></param>
                <param><value><string>".$function."</string></value></param> 
                <param>
                <value>
                    <array>
                    <data>
                        <value><int>".$value_so."</int></value> <!-- ID Sale Order -->
                        <value><int>".$journal_id."</int></value> <!-- ID dari Journal untuk pembayaran, misal bank -->
                        <value><double>".$amount."</double></value> <!-- Jumlah pembayaran -->
                        <value><int>".$company_id."</int></value> <!-- ID Company ID -->
                    </data>
                    </array>
                </value>
                </param>
            </params>
            </methodCall>";

        $this->create_invoice($xml_create_invoice);
        $message_odoo = 'Create Invoice success';
        return response()->json([
            'success' => true,
            'message_odoo' => $message_odoo,
            'message_oracle' => '',
            'data' => [array('name' => $name)],
        ]);
    }

    public function updatesol(Request $request)
    {
        $data_json = $request->input();

        $db = $this->db;
        $uid = $this->uid;
        $password = $this->password;
        $category = $data_json['category'];
        $function = $data_json['function'];
        $name = $data_json['name'];
        $product_template_id = $data_json['product_template_id'];
        $price_unit = $data_json['price_unit'];
        $product_uom_qty = $data_json['product_uom_qty'];
        $x_koli = $data_json['x_koli'];

        $xml_detail = "<methodCall>
            <methodName>execute_kw</methodName>
            <params>
                <param><value><string>".$db."</string></value></param>
                <param><value><int>".$uid."</int></value></param>
                <param><value><string>".$password."</string></value></param>
                <param><value><string>".$category."</string></value></param>
                <param><value><string>".$function."</string></value></param>
                <param>
                <value>
                    <array>
                    <data>
                        <value>
                        <array>
                            <data>
                            <value>
                                <array>
                                <data>
                                    <value><string>order_id.name</string></value> 
                                    <value><string>=</string></value> 
                                    <value><string>".$name."</string></value> 
                                </data>
                                </array>
                            </value>
                            </data>
                            <data>
                            <value>
                                <array>
                                <data>
                                    <value><string>product_template_id</string></value> 
                                    <value><string>=</string></value> 
                                    <value><int>".$product_template_id."</int></value>
                                </data>
                                </array>
                            </value>
                            </data>
                        </array>
                        </value>
                    </data>
                    </array>
                </value>
                </param>
                <param>
                <value>
                    <struct>
                    <member>
                        <name>fields</name>
                        <value>
                        <array>
                            <data>
                            <value><string>name</string></value> 
                            <value><string>product_id</string></value> 
                            <value><string>product_template_id</string></value> 
                            <value><string>order_id</string></value> 
                            </data>
                        </array>
                        </value>
                    </member>
                    </struct>
                </value>
                </param>
            </params>
        </methodCall>";
        $search_id_sol = $this->search_so($xml_detail);
        $xml = simplexml_load_string($search_id_sol);
        $id = (int)$xml->params->param->value->array->data->value->struct->member[0]->value->int;
        $name = (string)$xml->params->param->value->array->data->value->struct->member[1]->value->string;
        $product_id = (int)$xml->params->param->value->array->data->value->struct->member[2]->value->array->data->value[0]->int;
        $product_template_id = (int)$xml->params->param->value->array->data->value->struct->member[3]->value->array->data->value[0]->int;
        $order_id = (int)$xml->params->param->value->array->data->value->struct->member[4]->value->array->data->value[0]->int;
        $name_order = (string)$xml->params->param->value->array->data->value->struct->member[4]->value->array->data->value[1]->string;
        $simplified_data = [
            "id" => $id,
            "name" => $name,
            "product_template_id" => $product_template_id,
            "order_id" => $order_id,
            "name_order" => $name_order,
            "updated" => [array(
                'x_koli' => $x_koli,
                'product_uom_qty' => $product_uom_qty,
                'x_koli' => $x_koli,
                'price_unit' => $price_unit,
                )],
        ];
        $json = json_encode($simplified_data, JSON_PRETTY_PRINT);
        // echo $json;

        $message_oracle = '';
        $message_odoo = 'Updated';

        $xml_update = "
            <methodCall>
            <methodName>execute_kw</methodName>
            <params>
                <param><value><string>".$db."</string></value></param>
                <param><value><int>".$uid."</int></value></param>
                <param><value><string>".$password."</string></value></param>
                <param><value><string>sale.order.line</string></value></param>
                <param><value><string>write</string></value></param>
                <param>
                <value>
                    <array>
                    <data>
                        <value>
                        <array>
                            <data>
                            <!-- ID Sale Order Line yang ingin di-update -->
                            <value><int>".$id."</int></value> <!-- Ganti dengan ID Sale Order Line yang sebenarnya -->
                            </data>
                        </array>
                        </value>
                        <value>
                        <struct>
                            <!-- Field yang ingin di-update -->
                            <member>
                            <name>x_koli</name>
                            <value><double>".$x_koli."</double></value> <!-- Kuantitas -->
                            </member>
                            <member>
                            <name>product_uom_qty</name>
                            <value><double>".$product_uom_qty."</double></value> <!-- Kuantitas yang di-update -->
                            </member>
                            <member>
                            <name>price_unit</name>
                            <value><double>".$price_unit."</double></value> <!-- Harga per unit yang di-update -->
                            </member>
                        </struct>
                        </value>
                    </data>
                    </array>
                </value>
                </param>
            </params>
            </methodCall>";
        $update_sol = $this->update_so_sol($xml_update);
        return response()->json([
            'success' => true,
            'message_odoo' => $message_odoo,
            'message_oracle' => $message_oracle,
            'data' => $simplified_data,
        ]);
    }

    function search_so($xml){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function insert_so($xml){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function insert_sol($xml)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function update_so_sol($xml)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function create_invoice($xml)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
