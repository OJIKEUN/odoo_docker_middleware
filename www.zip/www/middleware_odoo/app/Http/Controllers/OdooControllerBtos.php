<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Odoo_so;
use App\Odoo_sol;
use DB;

class OdooControllerBtos extends Controller
{
    public function __construct()
    {
        // Production
        // $this->url_erp = 'http://159.223.61.53:8069/xmlrpc';
        // $this->db = 'perserobatam';
        // $this->uid = '2';
        // $this->password = 'iCARS2019';

        //Development
        $this->url_erp = 'http://localhost/odoo17/xmlrpc';
        $this->db = 'perserobatam';
        $this->uid = '0';
        $this->password = '2024@Batam';
        //11323
        //33188

        // Local Testing
        // $this->url_erp = 'http://host.docker.internal:8069/xmlrpc';
        // $this->db = 'testing1';
        // $this->uid = '0';
        // $this->password = 'testing1';

    }


    public function index(){

    }

    public function store(Request $request){
        $data_json = $request->input();

        $db = $this->db;
        $uid = $data_json['uid'];
        $password = $data_json['password'];
        $category = $data_json['category'];
        $function = $data_json['function'];
        $state = $data_json['state'];
        $name = $data_json['name'];
        $partner_id = $data_json['partner_id'];
        $payment_term_id = $data_json['payment_term_id'];
        $company_id = $data_json['company_id'];
        $pricelist_id = $data_json['pricelist_id'];
        $detail = $data_json['detail'];

        $xml = "<methodCall>
                    <methodName>execute_kw</methodName>
                    <params>
                        <!-- Authentication Parameters -->
                        <param><value><string>".$db."</string></value></param>
                        <param><value><int>".$uid."</int></value></param>
                        <param><value><string>".$password."</string></value></param>

                        <!-- Insert a Sale Order -->
                        <param><value><string>".$category."</string></value></param>
                        <param><value><string>".$function."</string></value></param>
                        <param>
                        <value>
                            <array>
                            <data>
                                <value>
                                <struct>
                                    <!-- Sale Order Fields -->
                                    <member>
                                    <name>name</name>
                                    <value>".$name."</value> <!-- Nomor WO -->
                                    </member>
                                    <member>
                                    <name>partner_id</name>
                                    <value><int>".$partner_id."</int></value> <!-- Partner ID / Customer ID -->
                                    </member>
                                    <member>
                                    <name>state</name>
                                    <value><string>".$state."</string></value>
                                    </member>
                                    <member>
                                    <name>payment_term_id</name>
                                    <value><int>".$payment_term_id."</int></value>
                                    </member>
                                    <member>
                                    <name>company_id</name>
                                    <value><int>".$company_id."</int></value> <!-- Default -->
                                    </member>
                                    <member>
                                    <name>pricelist_id</name>
                                    <value><int>".$pricelist_id."</int></value>
                                    </member>
                                </struct>
                                </value>
                            </data>
                            </array>
                        </value>
                        </param>
                    </params>
                </methodCall>";
        
            $xmlsearchso = "<methodCall>
                <methodName>execute_kw</methodName>
                <params>
                    <param><value><string>".$db."</string></value></param>
                    <param><value><string>".$uid."</string></value></param>
                    <param><value><string>".$password."</string></value></param>

                    <param><value><string>".$category."</string></value></param>
                    <param><value><string>search</string></value></param>

                    <param>
                    <value>
                        <array>
                        <data>
                            <value>
                            <array>
                                <data>
                                <value>
                                    <array>
                                    <data>
                                        <value><string>name</string></value>
                                        <value><string>=</string></value>
                                        <value><string>".$name."</string></value>
                                    </data>
                                    </array>
                                </value>
                                </data>
                            </array>
                            </value>
                        </data>
                        </array>
                    </value>
                    </param>
                </params>
            </methodCall>";

        //Update-30/06
        $data_response_so = $this->search_so($xmlsearchso);
        // dd($xmlsearchso);
        $xml_object_so = simplexml_load_string($data_response_so);

        // Tambahkan pengecekan apakah XML parsing berhasil
        if ($xml_object_so === false) {
            $value_so = 0;
        } else {
            // Pastikan struktur XML ada sebelum mengakses
            if (isset($xml_object_so->params->param->value->array->data->value->int)) {
                $value_so = (int)$xml_object_so->params->param->value->array->data->value->int;
            } else {
                $value_so = 0;
            }
        }

        $result=[];
        if($value_so == 0){
            
            $data_response = $this->insert_so($xml);
            $xml_object = simplexml_load_string($data_response);

            // Tambahkan pengecekan untuk XML parsing
            if ($xml_object === false) {
                $value = 0;
            } else {
                $json_array = json_decode(json_encode($xml_object), true);
                
                // Tambahkan pengecekan untuk struktur array
                if (isset($json_array['params']['param']['value']['int'])) {
                    $value = $json_array['params']['param']['value']['int'];
                } else {
                    $value = 0;
                }
            }

            $odoo_so_oracle                 = new Odoo_so();
            $odoo_so_oracle->DB_            = $db;
            $odoo_so_oracle->UID_           = $uid;
            $odoo_so_oracle->PASSWORD_      = $password;
            $odoo_so_oracle->CATEGORY_      = $category;
            $odoo_so_oracle->FUNCTION_      = $function;
            $odoo_so_oracle->ORDER_NAME_    = $name;
            $odoo_so_oracle->PARTNER_ID_    = $partner_id;
            $odoo_so_oracle->COMPANY_ID_    = $company_id;
            $odoo_so_oracle->XML            = $xml;
            $odoo_so_oracle->SO_ID          = $value;
            if(auth()->user()->odoo_sos()->save($odoo_so_oracle)){
                $message_oracle = 'Insert success';
            }else{
                $message_oracle = 'Insert failed';
            }

            if($company_id == '25'){
            //     $xml_to_so = "<methodCall>
            //         <methodName>execute_kw</methodName>
            //         <params>
            //             <!-- Authentication Parameters -->
            //             <param><value><string>".$db."</string></value></param>
            //             <param><value><int>".$uid."</int></value></param>
            //             <param><value><string>".$password."</string></value></param>
    
            //             <!-- Update Sale Order -->
            //             <param><value><string>sale.order</string></value></param> <!-- Model yang di-update -->
            //             <param><value><string>write</string></value></param> <!-- Metode untuk update data -->
            //             <param>
            //             <value>
            //                 <array>
            //                 <data>
            //                     <!-- ID dari sale order yang ingin di-update -->
            //                     <value>
            //                     <array>
            //                         <data>
            //                         <value><int>".$value."</int></value> <!-- ID sale order, ganti dengan ID SO yang sebenarnya -->
            //                         </data>
            //                     </array>
            //                     </value>
    
            //                     <!-- Data yang akan di-update -->
            //                     <value>
            //                     <struct>
            //                         <!-- Update field partner_id -->
            //                         <member>
            //                         <name>state</name>
            //                         <value><string>sale</string></value> <!-- Replace with actual partner_id -->
            //                         </member>
    
            //                         <!-- Update atau tambahkan order lines -->
                        
            //                     </struct>
            //                     </value>
            //                 </data>
            //                 </array>
            //             </value>
            //             </param>
            //         </params>
            //         </methodCall>";
            //     $update_so = $this->update_so_sol($xml_to_so);
                $message_update = "Update so success";
            }else{
                $message_update = "Update so failed";
            }

            $message_odoo = 'Insert success';
            foreach($detail as $rw){
                $xml_detail = "<methodCall>
                <methodName>execute_kw</methodName>
                    <params>
                        <param><value><string>".$db."</string></value></param>
                        <param><value><int>".$uid."</int></value></param> <!-- UID -->
                        <param><value><string>".$password."</string></value></param>
                        <param><value><string>".$rw['category']."</string></value></param>
                        <param><value><string>".$function."</string></value></param>
                        <param>
                        <value>
                            <array>
                            <data>
                            
                                <value>
                                <struct>
                                    <member>
                                    <name>order_id</name>
                                    <value><int>".$value."</int></value>
                                    </member>
                                    <member>
                                    <name>product_template_id</name>
                                    <value><int>".$rw['product_template_id']."</int></value>
                                    </member>
                                    <member>
                                    <name>product_id</name>
                                    <value><int>".$rw['product_id']."</int></value> <!-- ID Produk -->
                                    </member>
                                    <member>
                                    <name>name</name>
                                    <value><string>".$rw['name']."</string></value> <!-- Nama produk atau deskripsi -->
                                    </member>
                                    <member>
                                    <name>price_unit</name>
                                    <value><double>".$rw['price_unit']."</double></value> <!-- Harga per unit -->
                                    </member>
                                    <member>
                                    <name>x_koli</name>
                                    <value><double>".$rw['x_koli']."</double></value> <!-- Kuantitas -->
                                    </member>
                                    <member>
                                    <name>product_uom_qty</name>
                                    <value><double>".$rw['product_uom_qty']."</double></value> <!-- Kuantitas -->
                                    </member>
                                    <member>
                                    <name>customer_lead</name>
                                    <value><double>".$rw['customer_lead']."</double></value> <!-- Lead time -->
                                    </member>
                                    <member>
                                    <name>product_uom</name>
                                    <value><int>".$rw['product_uom']."</int></value> <!-- ID UOM (Unit of Measure) -->
                                    </member>
                                    <member>
                                    <name>container_code</name>
                                    <value><string>".$rw['container_code']."</string></value> <!-- ID UOM (Unit of Measure) -->
                                    </member>
                                    <member>
                                    <name>status_container</name>
                                    <value><string>".$rw['status_container']."</string></value> <!-- ID UOM (Unit of Measure) -->
                                    </member>
                                    <member>
                                    <name>price_unit_calculation_detail</name>
                                    <value><string>".$rw['price_unit_calculation_detail']."</string></value> <!-- ID UOM (Unit of Measure) -->
                                    </member>
                                    <!-- <member>
                                    <name>tax_id</name>
                                    <value>
                                        <array>
                                        <data>
                                            <value><int>1</int></value>  --> <!-- ID Pajak -->
                                        <!--</data>
                                        </array>
                                    </value>
                                    </member>
                                    -->
                                </struct>
                                </value>
                            </data>
                            </array>
                        </value>
                        </param>
                    </params>
                </methodCall>";

                $data_response_detail = $this->insert_so($xml_detail);
                $xml_details = simplexml_load_string($data_response_detail);
                // Tambahkan pengecekan apakah XML parsing berhasil
                if ($xml_object_so === false) {
                    $value_so = 0;
                } else {
                    // Pastikan struktur XML ada sebelum mengakses
                    if (isset($xml_object_so->params->param->value->array->data->value->int)) {
                        $value_so = (int)$xml_object_so->params->param->value->array->data->value->int;
                    } else {
                        $value_so = 0;
                    }
                }
                // echo $value_detail;
                $odoo_sol_oracle                        = new Odoo_sol();
                $odoo_sol_oracle->DB_                   = $db;
                $odoo_sol_oracle->UID_                  = $uid;
                $odoo_sol_oracle->PASSWORD_             = $password;
                $odoo_sol_oracle->CATEGORY_             = $category;
                $odoo_sol_oracle->FUNCTION_             = $function;
                $odoo_sol_oracle->ORDER_ID_            = $value;
                $odoo_sol_oracle->PRODUCT_TEMPLATE_ID_ = $rw['product_template_id'];
                $odoo_sol_oracle->PRODUCT_ID_          = $rw['product_id'];
                $odoo_sol_oracle->DESCRIPTION_         = $rw['name'];
                $odoo_sol_oracle->PRICE_UNIT_          = $rw['price_unit'];
                $odoo_sol_oracle->X_KOLI_              = $rw['x_koli'];
                $odoo_sol_oracle->PRODUCT_UOM_QTY_     = $rw['product_uom_qty'];
                $odoo_sol_oracle->CUSTOMER_LEAD        = $rw['customer_lead'];
                $odoo_sol_oracle->PRODUCT_UOM          = $rw['product_uom'];
                $odoo_sol_oracle->TAX_ID               = '';
                $odoo_sol_oracle->XML                  = '';
                // $odoo_sol_oracle->XML                  = $xml_detail;
                // $odoo_sol_oracle->SOL_ID               = $value_detail;
                
                // Proses response dengan validasi
                $xml_details = simplexml_load_string($data_response_detail);
                $value_detail = 0; // Default value

                if ($xml_details !== false && isset($xml_details->params->param->value->int)) {
                    $value_detail = (int)$xml_details->params->param->value->int;
                }

                $odoo_sol_oracle->SOL_ID = $value_detail;

                if(auth()->user()->odoo_sols()->save($odoo_sol_oracle)){
                    
                }
                // var_dump($rw['product_template_id']);
                $result_detail[] = array_merge($result, array(
                    'id' => $value_detail,
                    'btos_id' => $rw['btos_id'],
                    'name' => $rw['name'], 
                    'price_unit' => $rw['price_unit'], 
                    'x_koli' => $rw['x_koli'], 
                    'product_uom_qty' => $rw['product_uom_qty'],
                    'container_code' => $rw['container_code'],
                    'status_container' => $rw['status_container'],
                    'price_unit_calculation_detail' => $rw['price_unit_calculation_detail']
                ));
            }
        }else{
            $message_odoo = 'Row is ready';
            $message_oracle = 'Row is ready';
            $value = $value_so;
            $result_detail[] = array_merge($result, array(
                'id' => '', 
                'name' => '', 
                'price_unit' => '', 
                'x_koli' => '', 
                'product_uom_qty' => ''
            ));
        }
        
        return response()->json([
            'success' => true,
            'message_odoo' => $message_odoo,
            'message_oracle' => $message_oracle,
            // 'message_update' => $message_update,
            'data' => [
                array(
                    'name' => $name, 
                    'id' => $value, 
                    'details' => [$result_detail]
                )
            ],
        ]);
    }

    public function createInvoice(Request $request)
    {
        $data_json = $request->input();

        $db = $data_json['db'];
        $uid = $data_json['uid'];
        $password = $data_json['password'];
        $category = $data_json['category'];
        $function = $data_json['function'];
        $name = $data_json['name'];
        $journal_id = $data_json['journal_id'];
        $amount = $data_json['amount'];
        $company_id = $data_json['company_id'];
        $so_id = $data_json['so_id'];

        $xmlsearchso = "<methodCall>
                    <methodName>execute_kw</methodName>
                    <params>
                        <param><value><string>".$db."</string></value></param>
                        <param><value><string>".$uid."</string></value></param>
                        <param><value><string>".$password."</string></value></param>

                        <param><value><string>".$category."</string></value></param>
                        <param><value><string>search</string></value></param>

                        <param>
                        <value>
                            <array>
                            <data>
                                <value>
                                <array>
                                    <data>
                                    <value>
                                        <array>
                                        <data>
                                            <value><string>name</string></value>
                                            <value><string>=</string></value>
                                            <value><string>".$name."</string></value>
                                        </data>
                                        </array>
                                    </value>
                                    </data>
                                </array>
                                </value>
                            </data>
                            </array>
                        </value>
                        </param>
                    </params>
                </methodCall>";

        $xml_to_so = "<methodCall>
            <methodName>execute_kw</methodName>
            <params>
                <param><value><string>".$db."</string></value></param>
                <param><value><int>".$uid."</int></value></param>
                <param><value><string>".$password."</string></value></param>
                <param><value><string>sale.order</string></value></param>
                <param><value><string>write</string></value></param>
                <param>
                <value>
                    <array>
                        <data>
                            <value>
                                <array>
                                    <data>
                                        <value><int>".$so_id."</int></value>
                                    </data>
                                </array>
                            </value>
                            <value>
                                <struct>
                                    <member>
                                        <name>state</name>
                                        <value><string>sale</string></value>
                                    </member>
                                </struct>
                            </value>
                        </data>
                    </array>
                </value>
                </param>
            </params>
        </methodCall>";

        //Update-30/06
        $update_so = $this->update_so_sol($xml_to_so);
        $data_response_so = $this->search_so($xmlsearchso);
        $xml_object_so = simplexml_load_string($data_response_so);

        // Tambahkan pengecekan apakah XML parsing berhasil
        if ($xml_object_so === false) {
            $value_so = 0;
        } else {
            // Pastikan struktur XML ada sebelum mengakses
            if (isset($xml_object_so->params->param->value->array->data->value->int)) {
                $value_so = (int)$xml_object_so->params->param->value->array->data->value->int;
            } else {
                $value_so = 0;
            }
        }
        // echo $update_so;
        
        //payload
        $xml_create_invoice = "<methodCall>
            <methodName>execute_kw</methodName>
            <params>
                <param><value><string>".$db."</string></value></param>
                <param><value><string>".$uid."</string></value></param>
                <param><value><string>".$password."</string></value></param>

                <param><value><string>".$category."</string></value></param>
                <param><value><string>".$function."</string></value></param> 
                <param>
                <value>
                    <array>
                    <data>
                        <value><int>".$so_id."</int></value> <!-- ID Sale Order -->
                        <value><int>".$journal_id."</int></value> <!-- ID dari Journal untuk pembayaran, misal bank -->
                        <value><double>".$amount."</double></value> <!-- Jumlah pembayaran -->
                        <value><int>".$company_id."</int></value> <!-- ID Company ID -->
                    </data>
                    </array>
                </value>
                </param>
            </params>
            </methodCall>";

        $create_invoice = str_replace("\n", '', $this->create_invoice($xml_create_invoice));
        $update_so = str_replace("\n", '', $update_so);
        // echo $xml_create_invoice;
        $message_odoo = 'Create Invoice success';
        return response()->json([
            'success' => true,
            'message_odoo' => $message_odoo,
            'message_oracle' => '',
            'data' => [
                'so_id' => $so_id,
                'name' => $name,
                'response_create_so' => $update_so,
                'response_create_invoice' => $create_invoice
            ],
        ]);
    }

    public function updatesol(Request $request)
    {
        $data_json = $request->input();

        $db = $this->db;
        $uid = $data_json['uid'];
        $password = $data_json['password'];
        $category = $data_json['category'];
        $function = $data_json['function'];
        $state = $data_json['state'];
        $name = $data_json['name'];
        $partner_id = $data_json['partner_id'];
        $payment_term_id = $data_json['payment_term_id'];
        $company_id = $data_json['company_id'];
        $pricelist_id = $data_json['pricelist_id'];
        $so_id = $data_json['so_id'];
        $detail = $data_json['detail'];

        $xml_detail = "<methodCall>
            <methodName>execute_kw</methodName>
            <params>
                <param><value><string>".$db."</string></value></param>
                <param><value><int>".$uid."</int></value></param>
                <param><value><string>".$password."</string></value></param>
                <param><value><string>".$category."</string></value></param>
                <param><value><string>".$function."</string></value></param>
                <param>
                <value>
                    <array>
                    <data>
                        <value><int>".$so_id."</int></value>
                        <value>
                        <array>
                            <data>";
        foreach($detail as $rw){
            $xml_detail .= "<value>
                <struct>
                    <member>
                    <name>product_template_id</name>
                    <value><int>".$rw['product_template_id']."</int></value>
                    </member>
                    <member>
                    <name>product_id</name>
                    <value><int>".$rw['product_id']."</int></value>
                    </member>
                    <member>
                    <name>price_unit</name>
                    <value><double>".$rw['price_unit']."</double></value>
                    </member>
                    <member>
                    <name>product_uom_qty</name>
                    <value><double>".$rw['product_uom_qty']."</double></value>
                    </member>
                    <member>
                    <name>customer_lead</name>
                    <value><double>".$rw['customer_lead']."</double></value>
                    </member>
                    <member>
                    <name>product_uom</name>
                    <value><int>".$rw['product_uom']."</int></value>
                    </member>
                    <member>
                    <name>container_code</name>
                    <value><string>".$rw['container_code']."</string></value>
                    </member>
                    <member>
                    <name>status_container</name>
                    <value><string>".$rw['status_container']."</string></value>
                    </member>
                    <member>
                    <name>price_unit_calculation_detail</name>
                    <value><string>".$rw['price_unit_calculation_detail']."</string></value>
                    </member>
                </struct>
                </value>";
        }

        $xml_detail .= "</data>
                        </array>
                        </value>
                    </data>
                    </array>
                </value>
                </param>
            </params>
            </methodCall>";

            // echo $xml_detail;
        $update_sol = $this->update_so_sol($xml_detail);
        // $simplified_data = [
        //     "id" => $id,
        //     "name" => $name,
        //     "product_template_id" => $product_template_id,
        //     "order_id" => $order_id,
        //     "name_order" => $name_order,
        //     "updated" => [array(
        //         'x_koli' => $x_koli,
        //         'product_uom_qty' => $product_uom_qty,
        //         'x_koli' => $x_koli,
        //         'price_unit' => $price_unit,
        //         )],
        // ];
        // $json = json_encode($simplified_data, JSON_PRETTY_PRINT);
        $update_sol = str_replace("\n", '', $update_sol);
        return response()->json([
            'success' => true,
            // 'message_odoo' => $message_odoo,
            // 'message_oracle' => $message_oracle,
            'message' => 'Success',
            'response_sol' => $update_sol
        ]);
    }

    function search_so($xml){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function insert_so($xml){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function insert_sol($xml)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function update_so_sol($xml)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    function create_invoice($xml)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $this->url_erp.'/2/object',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>$xml,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/xml'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
}