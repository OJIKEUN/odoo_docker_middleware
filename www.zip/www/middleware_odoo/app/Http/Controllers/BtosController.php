<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Invoice;
use DB;

class InvoiceController extends Controller
{
    public function __construct()
    {
        $this->url_erp = 'https://qa-erpbatam.ptsisi.id/api';
    }

    public function index(){
        $invoice = auth()->user()->invoices;
        return response()->json([
            'success'=>true,
            'data'=>$invoice,
        ]);
    }
}