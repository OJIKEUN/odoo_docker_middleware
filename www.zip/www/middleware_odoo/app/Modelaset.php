<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Modelaset extends Model
{
    //
}
