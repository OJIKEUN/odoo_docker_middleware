<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoice_btos extends Model
{
    protected $fillable = [
        'NAME', 'PAYMENT_DATE', 'NOMOR_PKK', 'USER_ID', 'UPDATED', 'CREATED',
        // 'INVOICE_NO', 'M_VESSEL_NAME', 'BOOK_NO', 'FLAG_IMPORT_EXPORT', 'VOYAGE', 'BANK_ACCOUNT', 
        // 'CUSTOMER_NAME', 'CUSTOMER_ADDRESS', 'M_BILLING_SERVICE_DETAIL_CODE', 'M_BILLING_SERVICE_DETAIL_DESC', 'CONTAINER_CODE', 'CONTAINER_SIZE', 
        // 'STATUS_FULL_EMPTY', 'QTY', 'UNIT_PRICE', 'SUB_AMOUNT', 'ACTUAL_INVOICE_NO'
    ];
}